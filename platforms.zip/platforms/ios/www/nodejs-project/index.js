/**
 * @author wxh on 2019/5/15
 * @copyright
 * @desc
 */

const express = require('express')
const app = express()


const nedb = require('nedb');
const path = require('path');
const async = require('async');
const Mock = require('mockjs');

console.log('00000000',process.env.NODE_DB)
const db = new nedb({
    filename: process.env.NODE_DB,
    autoload: true
});
db.ensureIndex({ fieldName: 'id', unique: true, sparse: true }, function (err) {
});

app.get('/insert', (req, res) => {
    let j = 0;
    let jmax = 1;
    if(req.query.num){
        jmax = req.query.num
    }
    async.whilst(
        ()=>j<jmax,
        (whileCb1)=>{
            j++;
            db.insert([{ id:Mock.mock('@id'),name: Mock.mock('@name'),csentence:Mock.mock('@csentence') }], (err, ret) => {
                if(j == jmax)  {
                    return res.json({
                        flag: '0000',
                        msg: '',
                        result:{
                            ok:true,
                            j:j
                        }
                    });
                }else {
                    whileCb1()
                }
            });

        },
        (err)=>{
            console.log(err);
        }
    )
});


app.get('/find', (req, res) => {
    let skip = 1;
    let limit = 50;

    if(req.query.index){
        skip = req.query.size * (req.query.index - 1);
    }
    if(req.query.size){
        limit = req.query.size
    }

    async.parallel({
        count: (done)=>{
            db.count({}, done);
        },
        find: (done)=>{
            db.find({}).skip(skip).limit(limit).exec(done);
        },
    },(error, results)=>{
        res.json({
            flag: '0000',
            msg: '',
            result:{
                ok:true,
                data:results
            }
        });
    });
});



app.get('/remove', (req, res) => {
// 删除所有记录
    db.remove({}, { multi: true }, function (err, numRemoved) {
        res.json({
            flag: '0000',
            msg: '',
            result:{
                ok:true,
                data:numRemoved
            }
        });
    });
});


app.listen(3000, () => console.log('Example app listening on port 3000!'))
